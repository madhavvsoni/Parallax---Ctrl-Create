# PARALLAX — 60-second pitch

**0–15 seconds — show the twist**

“Everyone knows how to solve a maze. PARALLAX asks you to solve two—with the same controls. Move left and your reflection moves right. The goal is to get both explorers onto their portals together.”

**15–30 seconds — reveal the puzzle**

“Here’s the catch: a wall stops only one explorer. What looks like an obstacle becomes a tool. You use it to hold one world still while you fix the other. It takes one move to understand, but coordinating both worlds changes how you think.”

**30–50 seconds — demonstrate thoughtful AI use**

“We used AI across the build, from interpreting the brief to implementing the game and checking it. We didn’t just trust generated levels: breadth-first search finds their shortest solutions. The same solver gives a useful hint from wherever the player is now. Our tests check all eight campaign levels and 366 daily puzzles. The build log records what worked and what failed.”

**50–60 seconds — close**

“PARALLAX runs offline from one HTML file, with touch controls, undo, sound, saved progress, and a new daily puzzle. Two worlds. One move. A little shift in perspective.”

## Reliable demo route

1. Open `index.html` before presenting. Turn sound on only after testing the venue volume.
2. On **First contact**, press Up four times, then Right four times. Show the mirrored movement and completion screen.
3. Open **Out of step**. Press Right, Up, Right, Right. On the last move, a wall holds Sol still while Luna moves. Explain that obstacles allow the explorers to move independently.
4. Press Hint to show a live suggested direction. Press Undo to show recovery.
5. If time remains, switch to Daily puzzle and open “Behind the build.”

## Before the judging table

- Test the actual browser, keyboard, window size, sound, and completion flow.
- Add your team name and public GitHub URL to your submission.
- The supplied rules require a public repository link; this local project has no remote configured.
- Be precise: engine and static checks passed; this environment could not launch a browser for automated visual QA.

# AI build log — PARALLAX

## Tools actually used

Codex assisted with selection, requirements extraction, design, implementation, documentation, and testing. Local shell tools, Node.js, Python standard library, and macOS PDFKit were used. Apple Vision OCR was attempted and failed. Chrome preview was attempted and failed to launch. No image-generation service, external model API, or downloaded framework was used.

## Implementation briefs (assistant-authored summaries)

The first entry below summarizes the initial user request. Entries 2–7 summarize implementation decisions and are **not additional user prompts or verbatim chat messages**. Every user-authored prompt visible in this project thread is archived verbatim at the end of this log.

1. **User request:** Read the supplied problem statements, rules, and skill resources; finalize a statement; build the best possible HTML frontend; save it to `/Users/madhav/Desktop/Pixathon`.
2. **Requirements brief:** Read all four statements and the 22-page rules deck. Choose a puzzle with a one-sentence twist and a strong short demo. Map the result to the scoring rubric and submission evidence.
3. **Mechanic brief:** Build two mazes controlled together, mirroring horizontal movement. Let walls anchor one explorer while the other moves. Require both portals to be occupied simultaneously.
4. **Level brief:** Make eight progressively harder levels and a deterministic daily puzzle. Use a search over both explorer positions to guarantee reachable goals and compute the minimum move count.
5. **Interface brief:** Create an interface with gold and lilac worlds, original geometric art, clear controls, responsive layout, and a single-file game that works offline with fallback fonts. A later user-directed restyle changed the surrounding page to a cool fog palette while retaining the world boards.
6. **Behavior brief:** Add free undo, restart, solver-based hints, local records, star ratings, opt-in synthesized sound, touch gestures, reduced motion, and result sharing with a download fallback.
7. **Verification brief:** Test known movement outcomes independently, validate campaign solutions, check a year of daily seeds, validate artifact integrity, and document any checks the environment cannot perform.

## Skills and resources consulted

- Supplied `superpowers-main/skills/verification-before-completion/SKILL.md`: require evidence before reporting success.
- Supplied `superpowers-main/skills/using-superpowers/SKILL.md` and brainstorming guidance: inspected for workflow context. The user delegated selection and implementation, so that authorization governed routine design decisions.
- Installed Sites skill: used its local-only, buildless HTML workflow and portable preview guidance. No hosted Site was registered or published.
- Supplied `awesome-design-md-main.zip`: consulted the Vercel design analysis for spacing, typographic hierarchy, and restrained component treatment. Relevant reference and license copied under `docs/references/`.

No additional skill download was needed. An attempted `pypdf` installation could not reach the package index; the work used built-in PDFKit instead. No new third-party runtime code was installed.

## What went wrong and how it was handled

1. **Assumption: PDF text extraction would be sufficient.** The problem statement PDF contained extractable text, but all 22 rules pages were scanned images. Apple Vision OCR failed inside the environment. The fallback rendered the pages into six contact sheets and read the rules visually. This revealed the 40% AI-use weighting and the AI_LOG/public-repository requirements.
2. **Assumption: package downloads were available.** `pypdf` installation failed because network name resolution was unavailable. Built-in macOS frameworks avoided the dependency entirely.
3. **Verification wording correction.** An initial test title said “every reachable campaign state” although the hint test sampled states. The title was corrected to “sampled reachable campaign states”; no exhaustive hint-state coverage is claimed.
4. **Browser preview unavailable.** Chrome terminated at launch. Browser rendering, audio, clipboard behavior, and touch interactions are not claimed as manually or automatically verified. Engine and static checks were completed instead, and the handoff includes a venue-browser checklist.

5. **Pitch demonstration correction.** A draft incorrectly described the first Right move of level two as asymmetric. Running the engine showed both explorers moved. The demo now uses Right, Up, Right, Right; the fourth move anchors Sol and moves Luna. A regression test checks that exact demonstration.

## Attribution and limits

The identity, geometry, CSS artwork, code, and synthesized audio were made for this project with AI assistance. The design-reference file retains its source license. The restyle requests Bricolage Grotesque and Figtree from Google Fonts when available; local fallbacks keep the game usable offline. There are no claimed human playtest results, invented model conversations, invented benchmark scores, or fabricated AI-generated asset provenance. The project is a complete browser game; it does not include a backend or global leaderboard.

## Complete user prompt archive

These are the user-authored messages visible in this project conversation, in order. Spelling and wording are preserved. The environment context supplied by the client is metadata rather than a user request; system/developer instructions and private internal reasoning are not represented here.

### 1. Initial project request

```text
Problem Stattememtns: /Users/madhav/Desktop/pixathon-problem-statements.pdf
Rules: /Users/madhav/Desktop/Rules.pdf
Skills: /Users/madhav/Downloads/MIT\ Hackathon
I have provided you with the list of rules, resources as well as the skills. Finalize a problem statement. Download whatever is needed, and whatever related skill id needed. Provide me with a frontend in .html. I am in a hackathon. And I will be needing a a god level project. Make it absolute best.
```

### 2. Project request with destination

```text
Problem Stattememtns: /Users/madhav/Desktop/pixathon-problem-statements.pdf
Rules: /Users/madhav/Desktop/Rules.pdf
Skills: /Users/madhav/Downloads/MIT\ Hackathon
I have provided you with the list of rules, resources as well as the skills. Finalize a problem statement. Download whatever is needed, and whatever related skill id needed. Provide me with a frontend in .html. I am in a hackathon. And I will be needing a a god level project. Make it absolute best. Save it in the provided repo link: /Users/madhav/Desktop/Pixathon
```

### 3. AI log and commit check

```text
Have you made the AI Log as well as the git commits?
```

### 4. Commit request

```text
commit
```

### 5. Intro removal request

```text
Remove this section. A LITTLE SHIFT IN PERSPECTIVE
Two worlds.
One move.
```

### 6. Copy and section changes

```text
Make the following changes:
1. A maze, with a mirror on its mind.
Guide two explorers to their portals.
Move one. The other mirrors you.

Simple to learn. Different to master. ↗

2. Remove this part: 01
One input. Two perspectives.

Left becomes right. Up stays up. A familiar maze starts to feel wonderfully unfamiliar.
02
Make a little space.

A wall holds one explorer in place. Use that pause to bring the other into alignment.
03
Find your own way through.

Eight worlds. No countdown. Undo freely, ask for a nudge, and enjoy the little epiphanies.

3. Remoev this:
A maze, with a mirror on its mind. Give two explorers to their portals. Move one, the other mirros you.

4. A PUZZLE IN TWO WORLDS
```

### 7. Resume request

```text
resume
```

### 8. Commit request

```text
commit
```

### 9. Full visual restyle brief

```text
You are a senior UI designer and front-end engineer. Restyle my existing puzzle game frontend (a two-world puzzle: Sol in World 1, Luna in World 2) without changing structure, logic or the worlds.

## Hard constraints (do not break)
1. Do NOT change the DOM structure, layout, component hierarchy or game logic. Same sidebar + main panel, same header, same stats, same controls row.
2. Do NOT change the two world boards: board background, border, cell colours, wall tiles (with the small diagonal slash), goal rings (dashed inner ring + centre dot), player blocks (rounded square with two eyes), grid size, spacing, radii and shadows must stay exactly as they are now. If they use CSS variables, leave those variables alone.
3. Do NOT change the mini elements: the swap arrow between the worlds, the keycap hints (Z, R, H, W A S D), the arrow-key buttons and the undo/restart/hint icons' meaning.
4. Only change the page background, typography, colours outside the worlds, and the styling of the sidebar, tabs, stats, buttons and text.

## Why
The current look reads as AI-generated: near-black page with a lime-green accent, monospaced ALL-CAPS wide-tracked labels, zero-padded numbering (01, 02), a sparkle icon, glassy outlined rounded cards. Remove all of these.

## New design direction
A light, cool "fog" page so the two dark worlds are the focal point. The only accent colours come from the worlds: Sol amber and Luna violet.

### Tokens (CSS variables on :root)
Light:
--page:#dcdbe4; --panel:#ecebf2; --side:#e2e0ea; --chip:#fbfaff; --btn:#dad8e5;
--ink:#1b1a24; --ink-2:#5f5d70; --ink-3:#a5a3b6;
--sol:#e3a650; --luna:#8f7de6;
Dark (prefers-color-scheme: dark, and [data-theme="dark"]):
--page:#12131a; --panel:#1b1c26; --side:#161720; --chip:#272835; --btn:#272835;
--ink:#ecebf5; --ink-2:#a3a1b6; --ink-3:#4b4c62;
Leave the worlds' own colours the same in both themes.

### Typography
- Display (title, numbers, sidebar heading, progress count): "Bricolage Grotesque", weight 600, letter-spacing -0.02em, fallback Georgia/serif.
- UI text: "Figtree" 400/500/600, fallback system-ui.
- No monospace anywhere. No ALL CAPS, no wide letter-spacing, no middle-dot meta strings.
- Sentence case for all labels ("Best path", "Follows your lead").
- Level title: clamp(32px, 4.6vw, 50px), line-height 1. Stat numbers: 30px display font, tabular lining figures. Stat labels: 13px, --ink-2, sentence case, above the number.
- Show numbers without leading zeros (0, 18, 0:00; "Level 6 of 8").

### Layout surfaces (same structure, new treatment)
- Page background: --page, no gradients, no noise, no glow.
- Main panel: --panel, radius 28px, no border, no shadow, overflow hidden.
- Sidebar: a tonal block (--side) on the left of the panel, 288px wide, no divider line needed.
- Remove outlined/glass cards and any hairline borders around the panel and the controls.

### Top bar
- Tabs: pill segmented control on --btn. Active tab: --ink background, --panel text. Inactive: --ink-2 text. Keep the small diagonal-arrow icon on "Daily puzzle". Show the journey count as a small muted "8".
- Right-side tagline "No rush. Just reason." in sentence case, 14px, --ink-2, no dot or icon.

### Sidebar: the "expedition" path (the one memorable element)
- Replace checkmarks with small 18px discs. Completed levels: a disc split exactly in half, left Sol amber, right Luna violet (hard-stop linear-gradient at 50%, not a soft gradient). Current level: same split disc with a 3px gap ring and a 2px --ink outer ring, plus the small arrow icon at the row's right, on a --chip rounded (12px) background, font-weight 600. Upcoming levels: an empty ring (2px --ink-3).
- Join the markers in each chapter with a 2px vertical line: solid between two completed levels, dashed otherwise.
- Rows are 44px tall. Keep the small muted level number before the name. Chapter headings (The Awakening / The Divergence / The Convergence): 13px, weight 600, --ink-2, sentence case.
- Bottom: "Worlds aligned" label with "4 of 8" in the display font, then 8 segmented bars (6px tall, 3px radius, 4px gap; filled = --ink, empty = --ink-3 at 50% opacity), then the line "Every small step changes the bigger picture." in 13.5px --ink-2.

### Main area
- Eyebrow above the title: "The Divergence, level 6 of 8" in 15px, --ink-2, weight 500, sentence case.
- World headers: coloured 9px dot + bold world name ("Sol") + muted "World 1"; on the right a muted descriptor ("The original" / "The reflection"). Footers: dot + name, right-aligned muted "Follows your lead" / "Mirrors left and right".
- Dot colours: Sol #e3a650, Luna #8f7de6.
- Hint sentence under the worlds: centred, 15.5px, --ink-2, NO sparkle icon, no divider line above the controls.

### Controls row
- Buttons (Undo, Restart, Hint): 44px tall, 12px radius, --btn fill, no outline, 16px stroke icons, label in weight 500, keycap in a small rounded 6px chip on --panel. Hover: background --chip. Undo disabled at 40% opacity.
- Arrow buttons: 44x44, same style, 8px gap.
- "Move with W A S D or" in 14px --ink-2 with small keycaps.

### Motion & accessibility
- No entrance animations or decorative motion. Only a quick background-colour change on button hover.
- Visible :focus-visible outline (2px --ink, 2px offset) on every button.
- Respect prefers-reduced-motion. Keep text contrast at WCAG AA.

### Responsive
- Under 980px: sidebar stacks above the main area.
- Under 700px: the two worlds stack vertically (rotate the swap arrow 90deg), stats wrap below the title, hide the "Move with WASD" hint, centre the button row.

## Process
1. Read the existing code and list which selectors/components control the worlds so you leave them untouched.
2. Introduce the tokens above and swap fonts via Google Fonts (Bricolage Grotesque opsz 12..96 wght 400..700, and Figtree 400/500/600).
3. Restyle only the non-world elements as specified.
4. When done, give me a short diff summary and confirm that the world boards render pixel-identical to before.
```

### 10. Footer removal during the restyle

```text
remove this: "Pixathon 2026 — Challenge 3
Behind the build ↗"
```

### 11. Completed-level marker correction

```text
In the section, where all the lavels are presented, I wnt you to that currently, if a level is completeted, it is represented by a circle filled with semi circle. with two different colors, but I want there to be  tick mark in green. Just that.
```

### 12. Final log and commit request

```text
Commit. Make an AI Log contaning all the prompts. And the project is complete.
```

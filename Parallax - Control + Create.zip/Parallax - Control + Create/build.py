"""Build the portable single-file frontend. Requires only Python's standard library."""
from pathlib import Path
root=Path(__file__).resolve().parent
html=(root/'src/page.html').read_text()
html=html.replace('/* STYLES */',(root/'src/style.css').read_text()+'\n'+(root/'src/fog.css').read_text())
for marker,filename in [('/* ENGINE */','engine.js'),('/* APP */','app.js')]:
    html=html.replace(marker,(root/'src'/filename).read_text())
(root/'index.html').write_text(html)
print(f'Built index.html ({len(html.encode()):,} bytes; Google Fonts are optional at runtime)')

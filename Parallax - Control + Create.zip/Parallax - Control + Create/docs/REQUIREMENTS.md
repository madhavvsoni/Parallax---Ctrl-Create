# Finalized statement and design

## Selection

**Statement 3 — Puzzle with a Twist**, from `pixathon-problem-statements.pdf`, page 3.

Base puzzle: a maze. Twist: two explorers move from one input; horizontal controls reflect across the two worlds, and obstacles affect each independently.

Working title: **PARALLAX — Two worlds. One move.**

The intended audience is a first-time judge or player. The first level is an eight-move orientation; later puzzles make obstacle-based alignment essential. All levels are available without unlocking so judges can immediately inspect difficulty.

## Required behavior

| Supplied requirement | Implementation / evidence |
| --- | --- |
| Runs in the browser | Self-contained `index.html`; no runtime dependencies |
| Base puzzle + twist in one line on start screen | Hero explains a maze, two explorers, and mirrored movement |
| At least 3 levels or a generator | Eight campaign levels and a deterministic daily generator |
| Every level solvable; test it | BFS verifies campaign shortest paths; tests check 366 daily seeds |
| Win state and restart | Both portals occupied triggers completion; restart button / R work without reload |

## Rules reviewed

`Rules.pdf` is an image-based, 22-page orientation deck. It was rendered with macOS PDFKit and read visually. OCR failed; no OCR output is treated as evidence.

- Page 3: playable puzzle game; two-hour event framing.
- Pages 4–5: 100-point rubric; repo, AI_LOG.md, and pitch are judging evidence.
- Page 6: include 5–10 key prompts, tools used, and an instance where AI got something wrong; keep commit history; discuss AI in the pitch.
- Page 7: submission requires a public repository link; a live link is optional.
- Page 18: prioritize a playable loop, levels, solver verification, polish, and a 60-second pitch.

## Rubric response

| Category | Points | Project response |
| --- | ---: | --- |
| Smart use of AI | 40 | Documented decision process, deterministic generator, shared solver, tests, honest failure log |
| Creativity / originality | 20 | Specific mirrored maze composition and wall-based coordination; original art and identity |
| Usability | 15 | Visible goal, first-level introduction, instructions, keyboard/buttons/swipe, free undo |
| Feel / design | 10 | Gold/lilac worlds against a cool fog page, feedback, opt-in procedural sound |
| Pitch | 10 | Ready 60-second script and brief live demo |
| Fun | 5 | Increasing challenge, stars, daily puzzle, short restart loop |

These are design responses, not predicted scores. No claim is made that mirrored mazes have never existed before.

## Implementation decisions

Vanilla HTML/CSS/JavaScript was chosen to meet the requested `.html` handoff and work without downloads at the venue. The alternative of a framework/server adds setup without helping this local puzzle. A CAPTCHA game was considered less suited to a deep deterministic level progression; an open-innovation submission adds ambiguity where Statement 3 fits directly.

The engine represents each explorer as a cell index. BFS searches the pair of positions, at most n^4 states for an n×n pair of boards. A blocked explorer stays in place. Campaign boards after the tutorial are reproducibly generated from fixed seeds; goals are selected from reachable states at target distances. The daily board uses a local-date seed. The same transition function powers play, generation, and hints; targeted independent expectation tests verify the transition rules.

The design uses supplied design-reference principles (typographic hierarchy, spacing, restrained borders), with original game-specific layout, palette, SVG art, and sound. Raster generation was unnecessary for a grid-based game.

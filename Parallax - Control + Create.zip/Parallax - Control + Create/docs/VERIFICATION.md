# Verification

Executed on 2026-10-23.

- `python3 build.py` — built the standalone HTML from source.
- `node --check src/engine.js` — passed.
- `node --check src/app.js` — passed.
- `node --test tests/engine.test.cjs` — 16 tests passed, zero failures. Full output: `test-results.txt`.
- `python3 tests/check-html.py` — passed. Checks HTML nesting, unique IDs, static JavaScript selector targets, source/artifact equality, protected world selectors, and responsive/accessibility hooks.

## Coverage

All eight campaign levels have valid start/goal geometry and verified shortest solutions. Targeted tests verify mirrored horizontal controls, shared vertical controls, independent wall collisions, board edges, simultaneous win detection, and moving off a portal. Solver behavior is checked on unreachable inputs and sampled reachable states. Daily determinism and solvability are tested for 366 consecutive dates.

## Limits

Chrome terminated at launch in this execution environment. No browser screenshot, visual inspection of the rendered game, DOM interaction test, touch test, audio test, clipboard test, or measured accessibility audit was completed. Static checks cannot establish those properties. Open `index.html` in the actual presentation browser and use the checklist in `PITCH.md` before judging.

The fog restyle leaves `src/style.css` and `src/engine.js` byte-for-byte unchanged. The new `src/fog.css` contains no board, cell, portal, or player-block selectors. A source comparison confirmed the play section keeps its element hierarchy; a later explicit footer removal drops the event label and build link. Secondary text contrast against light and dark panels and buttons was checked at 4.54:1 or better. Board styling remains unchanged at a given size; the requested wider sidebar and responsive stacking can change the boards' rendered dimensions and position.

Storage is browser-local. A blocked storage API is handled without disabling gameplay. Daily puzzles use the device's local date, so players in different time zones may temporarily see different dates. Exported progress is a record; import is not implemented.

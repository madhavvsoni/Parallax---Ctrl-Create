/* PARALLAX: dependency-free, deterministic puzzle engine. */
(function(root) {
'use strict';
const DIRS = {up:[0,-1],right:[1,0],down:[0,1],left:[-1,0]};
function step(level,state,direction) {
 const d=DIRS[direction]; if(!d) return [...state];
 return state.map((pos,i)=>{
  const x=pos%level.size, y=Math.floor(pos/level.size), dx=i===0?d[0]:-d[0];
  const nx=x+dx,ny=y+d[1];
  return nx<0||ny<0||nx>=level.size||ny>=level.size||level.walls[i].includes(ny*level.size+nx)?pos:ny*level.size+nx;
 });
}
const key=s=>s.join(',');
const won=(l,s)=>s[0]===l.goals[0]&&s[1]===l.goals[1];
function explore(level,start=level.start) {
 const nodes=[{state:[...start],parent:-1,dir:null,depth:0}]; const seen=new Set([key(start)]);
 for(let head=0;head<nodes.length;head++) {
  for(const dir of Object.keys(DIRS)) {
   const next=step(level,nodes[head].state,dir),k=key(next);
   if(!seen.has(k)) {seen.add(k);nodes.push({state:next,parent:head,dir,depth:nodes[head].depth+1});}
  }
 }
 return nodes;
}
function solve(level,start=level.start) {
 if(won(level,start)) return [];
 const nodes=explore(level,start); let i=nodes.findIndex(n=>won(level,n.state));
 if(i<0)return null;
 const path=[];while(nodes[i].parent!==-1){path.unshift(nodes[i].dir);i=nodes[i].parent;}return path;
}
function random(seed) {let a=seed>>>0;return ()=>{a+=0x6D2B79F5;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296;};}
function generate(seed,size,target) {
 const rng=random(seed),start=[(size-1)*size,size*size-1];
 for(let attempt=0;attempt<100;attempt++) {
  const walls=[[],[]];
  for(let i=0;i<2;i++) for(let p=0;p<size*size;p++) if(p!==start[i]&&rng()<.24) walls[i].push(p);
  const level={size,start,walls,goals:[0,0]};const nodes=explore(level);
  const candidates=nodes.filter(n=>n.depth===target&&n.state[0]!==start[0]&&n.state[1]!==start[1]&&Math.floor(n.state[0]/size)<size-2&&Math.floor(n.state[1]/size)<size-2);
  if(candidates.length){level.goals=candidates[Math.floor(rng()*candidates.length)].state;level.par=target;return level;}
 }
 throw new Error('Unable to create level');
}
const intro={size:5,start:[20,24],goals:[4,0],walls:[[6,7,11,13,18],[6,8,12,13,16]],name:'First contact',chapter:'THE AWAKENING',note:'Left and right are mirrored. Up and down move together.',par:8};
const specs=[['Out of step',22,5,10,'A wall stops one explorer. The other keeps moving.'],['A little friction',61,5,12,'Use a wall as an anchor to bring the worlds into alignment.'],['Different paths',93,6,14,'The shortest route through one world may not help the other.'],['The space between',174,6,16,'Sometimes the way forward begins with a step back.'],['Beautiful resistance',287,6,18,'Walls are tools. Let one explorer wait while the other catches up.'],['Almost together',319,7,20,'An explorer can leave a portal. Both must arrive together.'],['Perfect alignment',411,7,24,'Two different journeys. One shared destination.']];
const levels=[intro,...specs.map(([name,seed,size,target,note],i)=>({...generate(seed,size,target),name,note,chapter:i<2?'THE AWAKENING':i<5?'THE DIVERGENCE':'THE CONVERGENCE'}))];
levels.forEach(l=>{l.par=solve(l).length;});
function daily(date) {let seed=0;for(const c of date)seed=(Math.imul(seed,31)+c.charCodeAt(0))>>>0;return {...generate(seed,6,17),name:'Daily transmission',chapter:'DAILY CHALLENGE',note:'A fresh maze for this date. Take your time.',date};}
const api={DIRS,step,won,solve,explore,generate,levels,daily};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.Parallax=api;
})(typeof globalThis!=='undefined'?globalThis:this);

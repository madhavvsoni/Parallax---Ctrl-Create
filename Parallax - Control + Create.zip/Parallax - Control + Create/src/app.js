(function(){
'use strict';
const E=Parallax,$=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const STORAGE='parallax-v1';let storageOK=true;
function cleanSave(raw){
 const safe={records:{},sound:false,reduced:false};
 if(!raw||typeof raw!=='object')return safe;
 safe.sound=raw.sound===true;safe.reduced=raw.reduced===true;
 for(const [k,v] of Object.entries(raw.records||{})){if(/^(level-[0-7]|daily-\d{4}-\d{2}-\d{2})$/.test(k)&&v&&Number.isInteger(v.moves)&&v.moves>0&&Number.isInteger(v.stars)&&v.stars>=1&&v.stars<=3)safe.records[k]={moves:v.moves,stars:v.stars};}
 return safe;
}
let save;try{save=cleanSave(JSON.parse(localStorage.getItem(STORAGE)));}catch(e){save=cleanSave(null);storageOK=false;}
let current=0,mode='campaign',level,state,history=[],moves=0,hints=0,started=0,elapsed=0,finished=false,trail=[new Set(),new Set()],toastTimer,resetConfirm=false,context;
const date=new Date();const dateKey=[date.getFullYear(),String(date.getMonth()+1).padStart(2,'0'),String(date.getDate()).padStart(2,'0')].join('-');
const dailyLevel=E.daily(dateKey);
function persist(){try{localStorage.setItem(STORAGE,JSON.stringify(save));}catch(e){storageOK=false;}$('#save-status').textContent=storageOK?'Progress saved on this device':'Storage unavailable — export to keep progress';}
function recordKey(){return mode==='daily'?'daily-'+dateKey:'level-'+current;}
function announce(message){$('#announcement').textContent=message;}
function toast(message){clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').hidden=false;toastTimer=setTimeout(()=>$('#toast').hidden=true,3400);}
function message(text){$('#game-message').replaceChildren();const icon=document.createElement('span');icon.className='spark';icon.textContent='✦';$('#game-message').append(icon,document.createTextNode(text));}
function timeText(t){return `${Math.floor(t/60)}:${String(t%60).padStart(2,'0')}`;}
function updateClock(){if(started&&!finished)elapsed=Math.floor((performance.now()-started)/1000);const [m,s]=timeText(elapsed).split(':');$('#timer').innerHTML=`${m}<small>:${s}</small>`;}
function tone(type){
 if(!save.sound)return;
 try{
  context??=new(window.AudioContext||window.webkitAudioContext)();context.resume().catch(()=>{});
  const notes=type==='win'?[392,523.25,659.25,783.99]:type==='bump'?[125]:type==='hint'?[440,554.37]:[mode==='daily'?330:293.66];
  notes.forEach((f,i)=>{const o=context.createOscillator(),g=context.createGain(),t=context.currentTime+i*.1;o.type='sine';o.frequency.value=f;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.075,t+.015);g.gain.exponentialRampToValueAtTime(.001,t+.3);o.connect(g);g.connect(context.destination);o.start(t);o.stop(t+.32);});
 }catch(e){/* Sound is optional; gameplay works without Web Audio. */}
}
function soundUI(){
 $('#sound').setAttribute('aria-pressed',String(save.sound));$('#sound').setAttribute('aria-label',save.sound?'Mute sound':'Enable sound');$('#sound-setting').checked=save.sound;
 $('#sound').innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 9h4l5-4v14l-5-4H4z"/>${save.sound?'<path d="M16 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>':'<path d="m17 9 5 6m0-6-5 6"/>'}</svg>`;
}
function setSound(value){save.sound=value;soundUI();persist();if(value)tone('hint');}
function renderSidebar(){
 const list=$('#level-list');list.innerHTML='';
 if(mode==='daily'){
  const info=document.createElement('div');info.className='daily-info';info.innerHTML=`<div class="daily-seal">✳</div><div class="mono">${dateKey}</div><h3>A new day.<br>A new perspective.</h3><p>The same puzzle for everyone using this date. Take your time. Make it yours.</p><p>${save.records[recordKey()]?'✓ You aligned today’s worlds.':'Your daily worlds are waiting.'}</p>`;list.append(info);
 }else{
  let chapter='';E.levels.forEach((l,i)=>{
   if(l.chapter!==chapter){chapter=l.chapter;const label=document.createElement('div');label.className='chapter-label mono';label.textContent=chapter.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase());list.append(label);}
   const b=document.createElement('button');b.className='level'+(i===current?' active':'')+(save.records['level-'+i]?' completed':'');b.setAttribute('aria-label',`Level ${i+1}: ${l.name}${save.records['level-'+i]?', completed':''}`);b.setAttribute('aria-current',i===current?'step':'false');b.innerHTML=`<span class="num">${i+1}</span><span class="level-name">${l.name}</span><span class="level-mark">${i===current?'↗':''}</span>`;b.addEventListener('click',()=>load(i));list.append(b);
  });
 }
 const count=E.levels.filter((_,i)=>save.records['level-'+i]).length;$('#progress-count').textContent=`${count} of 8`;$('#progress-fill').style.width=`${count/8*100}%`;
}
function renderBoards(){
 [$('#board-a'),$('#board-b')].forEach((board,i)=>{
  board.style.setProperty('--size',level.size);board.replaceChildren();
  const at=state[i];board.setAttribute('aria-label',`${i===0?'Sol':'Luna'} ${level.size} by ${level.size} maze. Explorer row ${Math.floor(at/level.size)+1}, column ${at%level.size+1}. Portal row ${Math.floor(level.goals[i]/level.size)+1}, column ${level.goals[i]%level.size+1}. ${at===level.goals[i]?'On portal.':''}`);
  for(let p=0;p<level.size*level.size;p++){
   const cell=document.createElement('div');cell.className='cell';cell.setAttribute('aria-hidden','true');
   if(level.walls[i].includes(p))cell.classList.add('wall');
   else{
    if(trail[i].has(p))cell.classList.add('trail');
    if(p===level.goals[i]){const portal=document.createElement('div');portal.className='portal';cell.append(portal);}
    if(p===at){const piece=document.createElement('div');piece.className='piece';cell.append(piece);if(p===level.goals[i])cell.classList.add('docked');}
   }
   board.append(cell);
  }
 });
 $('#moves').textContent=String(moves);$('#undo').disabled=history.length===0;updateClock();
}
function load(index=0){
 if(mode==='campaign')current=index;level=mode==='daily'?dailyLevel:E.levels[current];state=[...level.start];history=[];moves=0;hints=0;started=0;elapsed=0;finished=false;trail=[new Set(),new Set()];
 $('#win-overlay').hidden=true;$('#game-panel').removeAttribute('aria-busy');$('#level-name').textContent=level.name;$('#level-kicker').textContent=mode==='daily'?`Daily puzzle for ${dateKey}`:`${level.chapter.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase())}, level ${current+1} of 8`;$('#par').textContent=String(level.par);$$('[data-move]').forEach(b=>b.classList.remove('hinted'));message(level.note);renderSidebar();renderBoards();announce(`${level.name}. ${level.note}`);
}
function finish(){
 finished=true;const stars=hints?1:moves<=level.par?3:moves<=level.par+5?2:1;
 const previous=save.records[recordKey()];save.records[recordKey()]={moves:Math.min(previous?.moves??Infinity,moves),stars:Math.max(previous?.stars??0,stars)};persist();renderSidebar();tone('win');
 const complete=mode==='campaign'&&E.levels.every((_,i)=>save.records['level-'+i]);
 $('#win-title').textContent=complete?'A new perspective.':'Worlds aligned.';$('#win-description').textContent=complete?'Eight worlds, brought together. The daily transmission is waiting.':moves===level.par&&!hints?'A perfect path. Not a single step out of place.':'Two different paths. A perfectly shared moment.';
 $('#win-stars').textContent=Array.from({length:3},(_,i)=>i<stars?'●':'○').join(' ');$('#win-stars').setAttribute('aria-label',`${stars} out of 3 stars`);$('#win-stats').textContent=`${moves} moves, ${timeText(elapsed)}, ${hints} hint${hints===1?'':'s'}`;
 $('#next-level').textContent=mode==='daily'?'Return to the journey →':current===7?'Try the daily puzzle →':'On to the next world →';$('#win-overlay').hidden=false;$('#next-level').focus();announce(`Worlds aligned! ${moves} moves, ${stars} stars.`);
}
function move(dir){
 if(finished||$('dialog[open]'))return;
 const next=E.step(level,state,dir);
 $$('[data-move]').forEach(b=>b.classList.remove('hinted'));
 if(next[0]===state[0]&&next[1]===state[1]){message('Both paths are blocked. Try another direction.');tone('bump');return;}
 if(!started)started=performance.now();history.push([...state]);state.forEach((p,i)=>trail[i].add(p));state=next;moves++;tone('move');
 if(state[0]===level.goals[0]||state[1]===level.goals[1])message('One explorer is home. Bring the other to its portal, too.');else message(level.note);
 renderBoards();announce(`Move ${moves}. Sol row ${Math.floor(state[0]/level.size)+1}, column ${state[0]%level.size+1}. Luna row ${Math.floor(state[1]/level.size)+1}, column ${state[1]%level.size+1}.`);
 if(E.won(level,state))finish();
}
function undo(){if(!history.length||finished)return;state=history.pop();moves--;trail=[new Set(),new Set()];history.forEach(s=>s.forEach((p,i)=>trail[i].add(p)));$$('[data-move]').forEach(b=>b.classList.remove('hinted'));message('One step back. A fresh perspective.');renderBoards();announce('Last move undone.');}
function hint(){if(finished)return;const solution=E.solve(level,state);hints++;tone('hint');if(!solution?.length){message('These paths cannot meet from here. Undo a move or restart.');announce('No solution from this position. Try undo or restart.');return;}const dir=solution[0];$$('[data-move]').forEach(b=>b.classList.toggle('hinted',b.dataset.move===dir));message(`A little nudge: move ${dir}. ${solution.length} moves to alignment from here.`);announce(`Hint: move ${dir}.`);}
function switchMode(next){mode=next;$('#campaign-tab').classList.toggle('active',mode==='campaign');$('#daily-tab').classList.toggle('active',mode==='daily');$('#campaign-tab').setAttribute('aria-pressed',String(mode==='campaign'));$('#daily-tab').setAttribute('aria-pressed',String(mode==='daily'));load(mode==='campaign'?current:0);}
function download(name,text,type){const blob=new Blob([text],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('#campaign-tab').onclick=()=>switchMode('campaign');$('#daily-tab').onclick=()=>switchMode('daily');
$$('[data-move]').forEach(b=>b.onclick=()=>move(b.dataset.move));$('#undo').onclick=undo;$('#restart').onclick=()=>{load(current);toast('A clean slate. You’ve got this.');};$('#hint').onclick=hint;$('#replay').onclick=()=>{load(current);$('#restart').focus();};
$('#next-level').onclick=()=>{if(mode==='daily'){switchMode('campaign');}else if(current===7){switchMode('daily');}else load(current+1);$('#restart').focus();};
$('#sound').onclick=()=>setSound(!save.sound);$('#sound-setting').onchange=e=>setSound(e.target.checked);
$('#motion-setting').checked=save.reduced;document.body.classList.toggle('reduced',save.reduced);$('#motion-setting').onchange=e=>{save.reduced=e.target.checked;document.body.classList.toggle('reduced',save.reduced);persist();};
$$('[data-dialog]').forEach(b=>b.onclick=e=>{e.preventDefault();$('#'+b.dataset.dialog).showModal();});$$('[data-close]').forEach(b=>b.onclick=()=>b.closest('dialog').close());$$('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));
$('#settings').addEventListener('close',()=>{resetConfirm=false;$('#reset-warning').hidden=true;});
$('#export-progress').onclick=()=>download('parallax-progress.json',JSON.stringify({game:'PARALLAX',version:1,exportedAt:new Date().toISOString(),...save},null,2),'application/json');
$('#reset-progress').onclick=()=>{if(!resetConfirm){resetConfirm=true;$('#reset-warning').hidden=false;return;}save.records={};persist();resetConfirm=false;$('#reset-warning').hidden=true;$('#settings').close();load(current);toast('Saved records cleared. A new journey begins.');};
$('#share').onclick=async()=>{const result=`Parallax — ${level.name}${mode==='daily'?' — '+dateKey:''}\n${$('#win-stars').textContent}\n${moves} moves, best path ${level.par}, ${hints} hints, ${timeText(elapsed)}\nA mirrored maze puzzle.\nPixathon 2026 — Problem Statement 3`;try{await navigator.clipboard.writeText(result);toast('Result copied. Share your perspective.');}catch(e){download('parallax-result.txt',result,'text/plain');toast('Result saved as a text file.');}};
const keymap={ArrowUp:'up',ArrowRight:'right',ArrowDown:'down',ArrowLeft:'left',w:'up',d:'right',s:'down',a:'left'};
window.addEventListener('keydown',e=>{if(e.ctrlKey||e.metaKey||e.altKey||$('dialog[open]')||['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))return;const key=e.key.length===1?e.key.toLowerCase():e.key;if(keymap[key]){e.preventDefault();if(!e.repeat)move(keymap[key]);}else if(!e.repeat){if(key==='z')undo();if(key==='r')load(current);if(key==='h')hint();if(key==='m')setSound(!save.sound);}});
for(const board of [$('#board-a'),$('#board-b')]){let start=null;board.addEventListener('pointerdown',e=>{start={x:e.clientX,y:e.clientY};board.setPointerCapture(e.pointerId);});board.addEventListener('pointerup',e=>{if(!start)return;const dx=e.clientX-start.x,dy=e.clientY-start.y;start=null;if(Math.max(Math.abs(dx),Math.abs(dy))>22)move(Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up'));});board.addEventListener('pointercancel',()=>start=null);}
setInterval(updateClock,500);soundUI();load(0);persist();
})();

# PARALLAX

**Two worlds. One move.** A complete browser puzzle built for Pixathon 2026, playable offline with fallback fonts.

## Play immediately

Open **`index.html`** in Chrome, Safari, Firefox, or Edge. No installation, server, account, or API key is needed. The game works offline; when online, Google Fonts supplies Bricolage Grotesque and Figtree.

**Finalized problem statement: 03 — Puzzle with a Twist.**

> Navigate two mazes with one set of controls: horizontal movement is mirrored, and walls let you move one explorer independently.

Guide Sol (gold square) and Luna (lilac arch) onto their respective ring portals at the same time. Use arrow keys, WASD, on-screen buttons, or swipe either board. A portal does not freeze an explorer. A wall holds that explorer still while the other can move.

- `Z`: undo; `R`: restart; `H`: hint; `M`: toggle sound.
- Eight selectable campaign levels, with shortest solutions of 8, 10, 12, 14, 16, 18, 20, and 24 moves.
- A deterministic daily puzzle keyed to the device's local calendar date. People on the same date receive the same puzzle.
- Breadth-first-search hints from the current state, not a prerecorded answer.
- Local records, star ratings, optional synthesized sound, reduced-motion setting, touch gestures, keyboard controls, and result export.
- Three stars for a shortest solve without hints; two for up to five extra moves without hints; one otherwise. Undo is free. The timer is informational.

## Why this statement

The twist is explainable in one sentence and visible on the first move. Level one teaches mirrored controls; later levels require deliberately using walls as anchors. This provides a short judge-friendly demo, increasing difficulty, and a concrete way to show thoughtful AI use: generate, solve, verify, then iterate.

The supplied rules allocate 40 points to smart AI use, 20 to creativity/originality, 15 to usability, 10 to feel/design, 10 to pitch, and 5 to fun. See `docs/REQUIREMENTS.md` for source-page references and the requirements mapping.

## Submission files

- `index.html` — finished, standalone game; this is the file to open or host.
- `AI_LOG.md` — AI involvement, implementation briefs, failures, and every user-authored prompt visible in this project thread.
- `PITCH.md` — 60-second pitch and demonstration route.
- `docs/REQUIREMENTS.md` — finalized statement and rubric alignment.
- `docs/VERIFICATION.md` — executed checks and verification limits.
- `src/` — editable HTML, CSS, engine, and UI logic.
- `tests/` — dependency-free engine and artifact checks.

## Develop and verify

```sh
python3 build.py
node --check src/app.js
node --test tests/engine.test.cjs
python3 tests/check-html.py
```

`build.py` embeds the four source assets into `index.html`. It requires only Python's standard library. Tests use Node's built-in test runner (tested with Node 24). The shipped HTML does not need Python or Node.

Optional local server:

```sh
python3 -m http.server 8000
```

Then visit `http://localhost:8000`. Browser storage is scoped to the origin; opening a file and serving it may produce separate progress records. If browser storage is denied, gameplay remains available and the UI indicates that progress is temporary. Export progress from settings to retain a JSON record; this build does not include import.

## Verification boundary

Engine tests and static artifact checks pass. Automated visual/browser interaction testing could not run because Chrome exits at launch in this environment. Before presenting, open the game and check keyboard movement, touch layout, sound, dialogs, and completion in the actual presentation browser. No claim of a browser screenshot review is made.

## Public repository

The supplied path was an empty local folder, not a remote repository. This deliverable initializes a local Git repository. The rules (page 7) require a **public repository link** for submission; no GitHub URL or remote was supplied, so nothing has been published. Push this folder to your team's public repository before submitting. A live website link is optional according to that page.

## Assets and resources

All game artwork is original inline SVG/CSS. Audio is synthesized by Web Audio after user opt-in. Google Fonts supplies the optional display and UI fonts; the game uses local fallbacks when offline. No external image, paid service, or runtime JavaScript library is used. The supplied design collection informed spacing and typography; the relevant reference and its license are under `docs/references/`. Supplied verification guidance is documented in `AI_LOG.md`.

'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const E=require('../src/engine.js');
for(const [index,level] of E.levels.entries()){
 test(`Level ${index+1}: ${level.name} has valid geometry and a shortest ${level.par}-move solution`,()=>{
  assert.equal(level.walls.length,2);for(let i=0;i<2;i++){assert(!level.walls[i].includes(level.start[i]));assert(!level.walls[i].includes(level.goals[i]));assert(level.walls[i].every(p=>Number.isInteger(p)&&p>=0&&p<level.size**2));assert.equal(new Set(level.walls[i]).size,level.walls[i].length);}
  const solution=E.solve(level);assert(solution);assert.equal(solution.length,level.par);assert(level.par>=8);
  let state=[...level.start];for(const d of solution){const before=[...state];state=E.step(level,state,d);assert.notDeepEqual(state,before);state.forEach((p,i)=>assert(!level.walls[i].includes(p)));}assert(E.won(level,state));assert.deepEqual(E.solve(level,state),[]);
 });
}
test('Horizontal moves mirror; vertical moves are shared',()=>{const l={size:5,walls:[[],[]]};assert.deepEqual(E.step(l,[12,12],'left'),[11,13]);assert.deepEqual(E.step(l,[12,12],'right'),[13,11]);assert.deepEqual(E.step(l,[12,12],'up'),[7,7]);assert.deepEqual(E.step(l,[12,12],'down'),[17,17]);});
test('A wall anchors one explorer while the other moves',()=>{const l={size:5,walls:[[11],[]]};const s=[12,12];assert.deepEqual(E.step(l,s,'left'),[12,13]);assert.deepEqual(s,[12,12]);});
test('All board edges block correctly without row wrapping',()=>{const l={size:5,walls:[[],[]]};assert.deepEqual(E.step(l,[0,4],'left'),[0,4]);assert.deepEqual(E.step(l,[4,0],'right'),[4,0]);assert.deepEqual(E.step(l,[0,4],'up'),[0,4]);assert.deepEqual(E.step(l,[20,24],'down'),[20,24]);});
test('Reaching a portal does not freeze the explorer; both must align',()=>{const l={size:5,walls:[[],[]],goals:[12,12]};assert(!E.won(l,[12,11]));assert.deepEqual(E.step(l,[12,11],'up'),[7,6]);assert(E.won(l,[12,12]));});
test('Solver reports unreachable goals and ignores invalid directions',()=>{const l={size:3,walls:[[1,3],[1,3]],start:[0,0],goals:[8,8]};assert.equal(E.solve(l),null);assert.deepEqual(E.step(l,[0,0],'bad'),[0,0]);});
test('Hints work from sampled reachable campaign states (and identify dead ends)',()=>{for(const l of E.levels){const nodes=E.explore(l);for(let i=0;i<nodes.length;i+=Math.max(1,Math.floor(nodes.length/20))){const s=nodes[i].state,path=E.solve(l,s);if(path){let end=s;for(const d of path)end=E.step(l,end,d);assert(E.won(l,end));}else assert(!E.explore(l,s).some(n=>E.won(l,n.state)));}}});
test('Daily puzzles are deterministic, non-identical, and solvable for 366 consecutive dates',()=>{const first=E.daily('2026-10-23');assert.deepEqual(first,E.daily('2026-10-23'));assert.notDeepEqual(first.walls,E.daily('2026-10-24').walls);for(let i=0;i<366;i++){const date=new Date(Date.UTC(2026,0,1+i)).toISOString().slice(0,10),l=E.daily(date);const path=E.solve(l);assert(path,`${date} must be solvable`);assert.equal(path.length,17);assert(E.won(l,path.reduce((s,d)=>E.step(l,s,d),l.start)));}});

test('The pitch demo anchors Sol on the fourth move while Luna advances',()=>{const l=E.levels[1];let s=l.start;for(const d of ['right','up','right'])s=E.step(l,s,d);const next=E.step(l,s,'right');assert.equal(next[0],s[0]);assert.notEqual(next[1],s[1]);});

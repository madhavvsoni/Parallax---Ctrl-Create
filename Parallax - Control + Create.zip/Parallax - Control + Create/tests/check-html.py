"""Verify the self-contained artifact, selectors, and HTML structure without dependencies."""
from html.parser import HTMLParser
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
class Check(HTMLParser):
    def __init__(self):
        super().__init__();self.ids=set();self.stack=[];self.external=[];self.buttons=0
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:
            assert a['id'] not in self.ids, f'Duplicate ID: {a["id"]}'
            self.ids.add(a['id'])
        if tag in ['script','img','link']:
            url=a.get('src',a.get('href',''))
            if url and not url.startswith('data:'):self.external.append(url)
        if tag=='button':self.buttons+=1
        if tag not in ['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr','path','ellipse','circle']:
            self.stack.append(tag)
    def handle_endtag(self,tag):
        if tag in ['path','ellipse','circle']:return
        assert self.stack and self.stack[-1]==tag,f'Misnested {tag}: {self.stack[-3:]}'
        self.stack.pop()
html=(root/'index.html').read_text();check=Check();check.feed(html)
assert not check.stack,check.stack
assert not check.external,check.external
assert all(x not in html for x in ['/* STYLES */','/* ENGINE */','/* APP */'])
script=(root/'src/app.js').read_text()
for selector in re.findall(r"\$\('#([a-zA-Z][\w-]*)'\)",script):
    assert selector in check.ids,f'Missing element: {selector}'
for file in ['style.css','fog.css','engine.js','app.js']:
    assert (root/'src'/file).read_text() in html,f'Stale build: {file}'
for selector in ['board','cell','portal','piece']:
    assert not re.search(r'\.'+selector+r'(?![\w-])',(root/'src/fog.css').read_text()),f'Protected board selector changed: {selector}'
assert 'fonts.googleapis.com/css2' in html
assert 'prefers-reduced-motion' in html
assert 'aria-live="polite"' in html
assert 'name="viewport"' in html
print(f'PASS: valid nesting, {len(check.ids)} unique IDs, {check.buttons} static buttons, matching JS selectors.')
print('PASS: single-file artifact matches source; original world selectors untouched; Google Fonts have local fallbacks.')
